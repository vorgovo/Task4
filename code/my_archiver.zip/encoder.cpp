//
// Created by demon1999 on 05.06.18.
//
#include <set>
#include <iostream>
#include <cassert>
#include "encoder.h"

void encoder::put_dictionary() {
    for (unsigned long long int frequencie : frequencies) {
        last_piece.push(std::make_pair(frequencie, 64));
    }
}

void encoder::count_frequencies(std::string s, bool is_last_part) {
    for (char i : s) {
        frequencies[(unsigned char) i]++;
    }
    if (is_last_part) {
        my_dictionary.make_dictionary(frequencies);
        put_dictionary();
    }
}

std::string encoder::encode_text(std::string s, bool is_last_part) {
    std::string ans;
    ans = "";
    for (char c: s) {
        last_piece.push(my_dictionary.get_symbol((unsigned char)c));
    }
    if (is_last_part) {
        size_t pos = 0;
        auto v = my_dictionary.get_symbol(ALPHABET - 1);
        while (last_piece.size() % 8) {
            unsigned long long c = 0;
            if (v.first & (1ULL << (v.second - 1 - pos)))
                c = 1;
            last_piece.push(std::make_pair(c, 1));
            pos = (pos + 1) % v.second;
        }
    }
    while (last_piece.size() >= 8) {
        auto c = last_piece.size();
        ans += last_piece.pop_symbol();
        assert(c - last_piece.size() == 8);
    }

    return ans;
}
