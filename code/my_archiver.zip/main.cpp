#include <iostream>
#include "encoder.h"
#include "decoder.h"
const size_t SIZE = (1 << 20);
char buffer[SIZE], buffer_write[SIZE * 8 + 256 * 64];
std::string s;

void out_help() {
    std::cout << "help: ./archiver (-e | -d) source target" << std::endl;
    exit(0);
}
int main(int argc, char* argv[]) {
    if (argc != 4) {
        out_help();
    }
    auto option = std::string(argv[1]);
    FILE* fin = std::fopen(argv[2], "r");
    FILE* fout = std::fopen(argv[3], "w");
    if (option == "-e") {
        encoder my_encoder;
        while (!(std::feof(fin))) {
            auto cnt = fread(buffer, sizeof buffer[0], SIZE, fin);
            s.resize(cnt);
            std::copy(buffer, buffer + cnt, s.begin());
            my_encoder.count_frequencies(s, false);
        }
        my_encoder.count_frequencies("", true);
        fclose(fin);
        fin = std::fopen(argv[2], "r");
        while (!(std::feof(fin))) {
            auto cnt = fread(buffer, sizeof buffer[0], SIZE, fin);
            s.resize(cnt);
            std::copy(buffer, buffer + cnt, s.begin());
            auto ss = my_encoder.encode_text(s, false);
            for (size_t i = 0; i < ss.size(); i++)
                buffer_write[i] = ss[i];
            size_t sum = 0;
            while (sum < ss.size()) {
                sum += fwrite(buffer_write + sum, sizeof buffer_write[0], ss.size() - sum, fout);
            }
        }
        my_encoder.encode_text("", true);
    } else if (option == "-d") {
        decoder my_decoder;
        while (!(std::feof(fin))) {
            auto cnt = fread(buffer, sizeof buffer[0], SIZE, fin);
            s.resize(cnt);
            std::copy(buffer, buffer + cnt, s.begin());
            auto ss = my_decoder.decode_text(s);
            for (size_t i = 0; i < ss.size(); i++)
                buffer_write[i] = ss[i];
            size_t sum = 0;
            while (sum < ss.size()) {
                sum += fwrite(buffer_write + sum, sizeof buffer_write[0], ss.size() - sum, fout);
            }
        }
    } else {
        out_help();
    }
    std::fclose(fin);
    std::fclose(fout);
    return 0;
}