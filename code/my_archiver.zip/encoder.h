//
// Created by demon1999 on 05.06.18.
//

#include <cstring>
#include <string>
#include <algorithm>
#include <vector>
#include "dictionary.h"
#include "bit_queue.h"

#ifndef ARCHIVER_ARCHIEVER_H
#define ARCHIVER_ARCHIEVER_H

struct encoder {
    static const int ALPHABET = 257;
    encoder() {
        for (unsigned long long &frequencie : frequencies) {
            frequencie = 0;
        }
        frequencies[ALPHABET - 1] = 1;
    }
    ~encoder() = default;
    void count_frequencies(std::string s, bool is_last_part);
    std::string encode_text(std::string s, bool is_last_part);
private:
    unsigned long long frequencies[ALPHABET]{};
    dictionary my_dictionary;
    bit_queue last_piece;
    void put_dictionary();
};


#endif //ARCHIVER_ARCHIEVER_H
